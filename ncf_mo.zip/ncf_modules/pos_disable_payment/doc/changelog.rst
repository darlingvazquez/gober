.. _changelog:

Changelog
=========

`2.1.1`
-------

- User POS settings now got two parameters (allow_decrease_amount and allow_delete_order_line) instead of only one
(allow_delete_order_line). If first parameter is FALSE than you cant set second one..

`2.0.0`
-------

- Restrictions sets in User.

`1.0.0`
-------

- Restriction sets in POS.
