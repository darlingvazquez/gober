Sync POS orders across multiple sessions (restaurant extension)
===============================================================

Syncs additional restaurant data:

* Table and floor
* Guests number
* Printer status (green "Order" button)
* Notes

Local run
---------

If you use dbfilter, don't forget to specify correct proxy on printers

Further information
-------------------

Tested on Odoo 9 22e94f5254a35fc20ca536ed1b5e6a6cf315e4c4

Need our service?
-----------------

Contact us by `email <mailto:it@it-projects.info>`_ or fill out `request form <https://www.it-projects.info/page/website.contactus>`_:

* it@it-projects.info
* https://www.it-projects.info/page/website.contactus

