.. _changelog:

Changelog
=========

`1.1.3`
-------
- FIX: in some cases POS loading was stopped.

`1.1.2`
-------
- IMP: Sync printed positions.

`1.1.1`
-------
- IMP: Sync notes. Sync guests.

`1.1.0`
-------

- Removed virtual table. Added constraint of different floors in POS that has same multi session.

`1.0.1`
-------

- Every tables sync according to its floor

`1.0.0`
-------

- Allows to attach all synced orders to some (virtual) table.
