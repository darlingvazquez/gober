Sync POS orders across multiple sessions
========================================

Tested on Odoo 9.0 994cb2cb79b8fb91ec83b273213044f15b61095e
