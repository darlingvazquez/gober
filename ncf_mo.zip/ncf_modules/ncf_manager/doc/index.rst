Manejador de comprobantes fiscales
==================================